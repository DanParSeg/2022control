% Adapted from https://www.ensta-bretagne.fr/jaulin/

function  dx  = f(x,u)
    dx=[u(1);u(2)];
end

