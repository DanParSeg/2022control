function  dx  = f(x,u)
    x1=x(1);
    x2=x(2);
    x3=x(3);
    x4=x(4);
    tau=u;
    q1=x1;

    m1=200;
    m2=50;
    I1=25;
    I2=5;
    l1=1;
    lc1=0.5;
    g=9.81;

    dx=[x3; x4; -(tau - g*sin(q1)*(l1*m2 + lc1*m1))/(m2*l1^2 + m1*lc1^2 + I1); -(g*sin(q1)*(l1*m2 + lc1*m1) - (tau*(m2*l1^2 + m1*lc1^2 + I1 + I2))/I2)/(m2*l1^2 + m1*lc1^2 + I1)]

end

