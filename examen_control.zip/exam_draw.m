function f(x)
    clf();
    hold on;
    axis square;
    axis([-1,1,-0.5,1.5]*1.5)

    m1=200;
    m2=50;
    I1=25;
    I2=5;
    l1=1;
    lc1=0.5;
    g=9.81;
    
    q1=x(1);
    q2=x(2);
    
    Pendulo=[0 0;
             0 l1;
             1 1];

    M_rotate_pendulo=[cos(q1) -sin(q1) 0; 
              sin(q1) cos(q1) 0;
              0 0 1];

    Pendulo_transformed=M_rotate_pendulo*Pendulo;

    Rueda=[0 0;
           0 lc1;
           1 1];
    
    M_rotate_rueda=[cos(q2) -sin(q2) 0; 
              sin(q2) cos(q2) 0;
              0 0 1];

    M_translate_rueda=[1 0 0;
                0 1 1;
                0 0 1];

    Rueda_transformed=M_rotate_pendulo*M_translate_rueda*M_rotate_rueda*Rueda;

    plot(Pendulo_transformed(1,:),Pendulo_transformed(2,:),'black','LineWidth',1);
    plot(Rueda_transformed(1,:),Rueda_transformed(2,:),'red','LineWidth',1);  
end