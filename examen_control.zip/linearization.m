clear all

syms m1 m2 I1 I2 l1 lc1 g
syms u x1 x2 x3 x4

tau=u
q1=x1

%separamos dx en la forma Ax+Bu

dx=[x3; x4; -(tau - g*sin(q1)*(l1*m2 + lc1*m1))/(m2*l1^2 + m1*lc1^2 + I1); -(g*sin(q1)*(l1*m2 + lc1*m1) - (tau*(m2*l1^2 + m1*lc1^2 + I1 + I2))/I2)/(m2*l1^2 + m1*lc1^2 + I1)]

A = jacobian(dx,[x1;x2;x3;x4]);
B = jacobian(dx,[u]);

A=subs(A,[x1 x2 x3 x4], [0 0 0 0])
B=subs(B,[x1 x2 x3 x4], [0 0 0 0])



