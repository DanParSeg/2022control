syms m1 m2 I1 I2 l1 lc1 g
syms tau ddq1 ddq2 dq1 dq2 q1 q2

Eq1=(m1*lc1^2+m2*l1^2+I1+I2)*ddq1+I2*ddq2-(m1*lc1+m2*l1)*g*sin(q1)==0
Eq2=I2*ddq1+I2*ddq2==tau


%Eqddq1=solve(Eq1,ddq1)
%Eqddq2=solve(Eq1,ddq2)


%sabemos que x es [q1 q2 dq1 dq2], [x1 x2 x3 x4]
%sabemos que dx es [dq1 dq2 ddq1 ddq2], [x3 x4 ddq1 ddq2]
%tenemos que dejar el sistema así: dx=x+Bu

%sustituir todas las ddq1 y ddq2 por tau
tau_ddq1=solve(Eq2,ddq1)
tau_ddq2=solve(Eq2,ddq2)

%resuelvo para calcular x3 y x4
dx3=solve(subs(Eq1,ddq2,tau_ddq2),ddq1)
dx4=solve(subs(Eq1,ddq1,tau_ddq1),ddq2)
dx=[x3;x4;dx3;dx4]
%resultado:
dx=[x3; x4; -(tau - g*sin(q1)*(l1*m2 + lc1*m1))/(m2*l1^2 + m1*lc1^2 + I1); -(g*sin(q1)*(l1*m2 + lc1*m1) - (tau*(m2*l1^2 + m1*lc1^2 + I1 + I2))/I2)/(m2*l1^2 + m1*lc1^2 + I1)]

%{
Eqddq1=solve(Eq1,ddq1)
Eqddq2=solve(Eq2,ddq2)

B=[0;0;0;1/I2];
x3=-(I2*ddq2 - g*sin(q1)*(l1*m2 + lc1*m1))/(m2*l1^2 + m1*lc1^2 + I1 + I2);
x4=-ddq1;
resultdx=[dq1;dq2;x3;-ddq1]+B*tau
%}

