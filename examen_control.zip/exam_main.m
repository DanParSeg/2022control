m1=200;
m2=50;
I1=25;
I2=5;
l1=1;
lc1=0.5;
g=9.81;

A=[0, 0, 1, 0;
   0, 0, 0, 1;
   (g*(l1*m2 + lc1*m1))/(m2*l1^2 + m1*lc1^2 + I1), 0, 0, 0;
   -(g*(l1*m2 + lc1*m1))/(m2*l1^2 + m1*lc1^2 + I1), 0, 0, 0];
B=[0; 0; -1/(m2*l1^2 + m1*lc1^2 + I1); (m2*l1^2 + m1*lc1^2 + I1 + I2)/(I2*(m2*l1^2 + m1*lc1^2 + I1))]

Q=[1 0 0 0;
   0 0.000001 0 0;
   0 0 1 0;
   0 0 0 1];
R=[1];
K=lqr(A,B,Q,R,0)
E=[1 0 0 0];
H=-inv(E*inv(A-B*K)*B)

%QUEDAN 5 MINUTOS Y K NO FUNCIONA ASHJGFDKFGSVFGKDHSDFGKHSDGH

x=[0.261799;0;0;0];


dt=0.001;
frame_counter=0;
for t=0:dt:50
    x_bar=[0;0;0;0];
    w=0;
    w_bar=0;
    u_bar=0;
    u=u_bar-K*(x-x_bar)+H*(w-w_bar);
    x=x+exam_f(x,u)*dt;

    % Frame sampling
    if frame_counter == 0
       %answer_6_draw(t,x,u);
       exam_draw(x);
       pause(0.000000000000000000001);%to update plot
    end
    t
    frame_counter =frame_counter+1;
    if frame_counter == 10
        frame_counter=0;
    end
end

