syms m1 m2 I1 I2 l1 lc1 g
syms u x1 x2 x3 x4
dx=[x3; x4; -(tau - g*sin(q1)*(l1*m2 + lc1*m1))/(m2*l1^2 + m1*lc1^2 + I1); -(g*sin(q1)*(l1*m2 + lc1*m1) - (tau*(m2*l1^2 + m1*lc1^2 + I1 + I2))/I2)/(m2*l1^2 + m1*lc1^2 + I1)]

S = solve(dx(1)==0,dx(2)==0,dx(3)==0,dx(4)==0,u==0,x1,x3,x4,u,'Real',true);

Su=[S.u]
Sx=[S.x1;0;S.x3;S.x4]

%PUNTO EQ [0 - 0 0]